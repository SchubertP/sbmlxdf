from .model import Model

__version__ = '0.1'
__author__ = 'Peter Schubert'
