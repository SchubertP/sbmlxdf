from sbmlxdf._version import __version__

program_name = 'sbmlxdf'
__author__ = 'Peter Schubert'
